"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AaOidc = void 0;
/**
 * Utility methods for OpenID Connect process.
 */
class AaOidc {
    /**
     * Build the {@link OidcMetadata} properties from the environment variables.
     */
    static buildMetadata() {
        var _a, _b, _c, _d, _e, _f;
        const metadata = {};
        if ((_a = globalThis.env) === null || _a === void 0 ? void 0 : _a.OPENID_ISSUER) {
            metadata.issuer = globalThis.env.OPENID_ISSUER;
        }
        if ((_b = globalThis.env) === null || _b === void 0 ? void 0 : _b.OPENID_AUTHORIZATION_ENDPOINT) {
            metadata.authorization_endpoint = globalThis.env.OPENID_AUTHORIZATION_ENDPOINT;
        }
        if ((_c = globalThis.env) === null || _c === void 0 ? void 0 : _c.OPENID_USERINFO_ENDPOINT) {
            metadata.userinfo_endpoint = globalThis.env.OPENID_USERINFO_ENDPOINT;
        }
        if ((_d = globalThis.env) === null || _d === void 0 ? void 0 : _d.OPENID_END_SESSION_ENDPOINT) {
            metadata.end_session_endpoint = globalThis.env.OPENID_END_SESSION_ENDPOINT;
        }
        if ((_e = globalThis.env) === null || _e === void 0 ? void 0 : _e.OPENID_JWKS_URI) {
            metadata.jwks_uri = globalThis.env.OPENID_JWKS_URI;
        }
        if ((_f = globalThis.env) === null || _f === void 0 ? void 0 : _f.OPENID_CHECK_SESSION_IFRAME) {
            metadata.check_session_iframe = globalThis.env.OPENID_CHECK_SESSION_IFRAME;
        }
        return Object.keys(metadata).length > 0 ? metadata : undefined;
    }
    /**
     * Compute the options for the OpenId login popup.
     * @param w popup width
     * @param h popup height
     */
    static popupCenterOption(w, h) {
        // Fixes dual-screen position
        const dualScreenLeft = window.screenLeft ? window.screenLeft : window.screenX;
        const dualScreenTop = window.screenTop ? window.screenTop : window.screenY;
        const left = (window.screen.width - w) / 2 + dualScreenLeft;
        const top = (window.screen.height - h) / 2 + dualScreenTop;
        return `width=${w}, height=${h}, top=${top}, left=${left}`;
    }
    /**
     * Build the {@link UserManagerSettings} for the OpenId process from the environment variables.
     */
    static buildDefaultSettings() {
        var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r, _s;
        let defaultSettings = {
            authority: (_a = globalThis.env) === null || _a === void 0 ? void 0 : _a.OPENID_PROVIDER_ENDPOINT,
            client_id: (_b = globalThis.env) === null || _b === void 0 ? void 0 : _b.OPENID_CLIENT_ID,
            scope: (_c = globalThis.env) === null || _c === void 0 ? void 0 : _c.OPENID_CLIENT_SCOPES,
            redirect_uri: `${window.location.origin}${(_e = (_d = globalThis.env) === null || _d === void 0 ? void 0 : _d.REACT_APP_BASE_URL) !== null && _e !== void 0 ? _e : ''}/signin-redirect.html`,
            popup_redirect_uri: `${window.location.origin}${(_g = (_f = globalThis.env) === null || _f === void 0 ? void 0 : _f.REACT_APP_BASE_URL) !== null && _g !== void 0 ? _g : ''}/signin-popup.html`,
            popupWindowFeatures: `location=no,toolbar=no,${AaOidc.popupCenterOption(1024, 768)}`,
            silent_redirect_uri: `${window.location.origin}${(_j = (_h = globalThis.env) === null || _h === void 0 ? void 0 : _h.REACT_APP_BASE_URL) !== null && _j !== void 0 ? _j : ''}/silent-renew.html`,
            post_logout_redirect_uri: `${window.location.origin}${(_l = (_k = globalThis.env) === null || _k === void 0 ? void 0 : _k.REACT_APP_BASE_URL) !== null && _l !== void 0 ? _l : ''}`,
            popup_post_logout_redirect_uri: `${window.location.origin}${(_o = (_m = globalThis.env) === null || _m === void 0 ? void 0 : _m.REACT_APP_BASE_URL) !== null && _o !== void 0 ? _o : ''}/signout-popup.html`,
            automaticSilentRenew: false,
            accessTokenExpiringNotificationTime: 60,
            revokeAccessTokenOnSignout: true,
            response_type: ((_p = globalThis.env) === null || _p === void 0 ? void 0 : _p.OPENID_RESPONSE_TYPE) || 'id_token token',
        };
        if ((_q = globalThis.env) === null || _q === void 0 ? void 0 : _q.OPENID_LOAD_USERINFO) {
            defaultSettings = Object.assign(Object.assign({}, defaultSettings), { loadUserInfo: globalThis.env.OPENID_LOAD_USERINFO.toLowerCase() !== 'false' });
        }
        if ((_r = globalThis.env) === null || _r === void 0 ? void 0 : _r.OPENID_METADATA_URL) {
            defaultSettings = Object.assign(Object.assign({}, defaultSettings), { metadataUrl: (_s = globalThis.env) === null || _s === void 0 ? void 0 : _s.OPENID_METADATA_URL });
        }
        // Set the Metadata from the environment variables
        defaultSettings.metadata = AaOidc.buildMetadata();
        return defaultSettings;
    }
}
exports.AaOidc = AaOidc;
//# sourceMappingURL=OidcTools.js.map