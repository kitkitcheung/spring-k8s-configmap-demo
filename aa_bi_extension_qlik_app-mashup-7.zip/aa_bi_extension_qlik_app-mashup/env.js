// WARNING: This is a generated file, do not directly edit it!
// All its content is erased at each start or build of the application.
// If you want to update environment variables, you can edit the env file ".env.runtime.package",
// and run the following command again:
//     "aa-tools env-to-js -e .env.runtime.package public/env.js"
//
// Also, this plain JavaScript file will not be transpiled.
// It won't end up inside the main application JavaScript bundle as
// it will be just copied inside the build folder and imported in the 'index.html'.
window.env = {
    PROXY_BASEPATH: "",
    AA_API_URL: "",
    AUTHENTICATION_TYPE: "ApiKey",
    TOOL_TARGET_ENVIRONMENT: "enterprise",
    OPENID_PROVIDER_ENDPOINT: "https://accounts.yseop-cloud.com/auth/realms/yseop",
    OPENID_CLIENT_ID: "anna-staging-dev",
    OPENID_CLIENT_SCOPES: "openid profile email",
    OPENID_LOAD_USERINFO: "",
    OPENID_METADATA_URL: "",
    OPENID_ISSUER: "",
    OPENID_AUTHORIZATION_ENDPOINT: "",
    OPENID_USERINFO_ENDPOINT: "",
    OPENID_END_SESSION_ENDPOINT: "",
    OPENID_JWKS_URI: "",
    OPENID_CHECK_SESSION_IFRAME: "",
    OPENID_RESPONSE_TYPE: "",
    DEFAULT_UNIT: "\$",
    NUMBER_FORMATTING_LANGUAGE: "en-US",
    ENABLE_FEEDBACK: "false",
    ENABLE_DOCUMENT_STRUCTURE_RENDERING: "true",
    ENABLE_LEGACY_WORKFLOW: "false",
    LOGGING_LEVEL: "error",
    PUBLIC_URL: "/extensions/aa_bi_extension_qlik_app",
    PROJECT_ID: ""
};
