define(['./dist/extension'], (supernova) => supernova);
